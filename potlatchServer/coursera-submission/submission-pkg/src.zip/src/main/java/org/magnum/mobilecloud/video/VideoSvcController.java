/*
 * 
 * Copyright 2014 Jules White
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.magnum.mobilecloud.video;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;

@Controller
public class VideoSvcController {
	
	/**
	 * You will need to create one or more Spring controllers to fulfill the
	 * requirements of the assignment. If you use this file, please rename it
	 * to something other than "AnEmptyController"
	 * 
	 * 
		 ________  ________  ________  ________          ___       ___  ___  ________  ___  __       
		|\   ____\|\   __  \|\   __  \|\   ___ \        |\  \     |\  \|\  \|\   ____\|\  \|\  \     
		\ \  \___|\ \  \|\  \ \  \|\  \ \  \_|\ \       \ \  \    \ \  \\\  \ \  \___|\ \  \/  /|_   
		 \ \  \  __\ \  \\\  \ \  \\\  \ \  \ \\ \       \ \  \    \ \  \\\  \ \  \    \ \   ___  \  
		  \ \  \|\  \ \  \\\  \ \  \\\  \ \  \_\\ \       \ \  \____\ \  \\\  \ \  \____\ \  \\ \  \ 
		   \ \_______\ \_______\ \_______\ \_______\       \ \_______\ \_______\ \_______\ \__\\ \__\
		    \|_______|\|_______|\|_______|\|_______|        \|_______|\|_______|\|_______|\|__| \|__|
                                                                                                                                                                                                                                                                        
	 * 
	 */
	
	@Autowired
	VideoRepository repro;
	
	@RequestMapping(value="/go",method=RequestMethod.GET)
	public @ResponseBody String goodLuck(){
		
		return "Good Luck!";
	}
	
	//@GET(VIDEO_SVC_PATH)
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH,method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList()
	{
		Collection<Video> vCollection = (Collection<Video>) repro.findAll();
		return vCollection;
	}
	
	//@GET(VIDEO_SVC_PATH + "/{id}")
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}",method=RequestMethod.GET)
	public @ResponseBody Video getVideoById(
			@PathVariable(value="id") long id)
	{
		Video video = repro.findOne(id);
		return video;
	}
	
	//@POST(VIDEO_SVC_PATH)
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(
			@RequestBody Video v) 
	{
		repro.save(v);
		return v;
	}
	
	//@POST(VIDEO_SVC_PATH + "/{id}/like")
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH+"/{id}/like",method=RequestMethod.POST)
	public Void likeVideo(
			@PathVariable(value="id") long id,
			HttpServletResponse response,
			Principal principal)
	{
		int status = HttpServletResponse.SC_NOT_FOUND;
		Video video = repro.findOne(id);
		String username = (principal != null) ? principal.getName(): null;
		if (video != null )
		{		
			if (video.getLikes() == (long) 1 &&
				video.getLikesBy().contains(username) == true)
			{
				status = HttpServletResponse.SC_BAD_REQUEST;			
			}
			else
			{
				status = HttpServletResponse.SC_OK;				
				video.setUserLikes(username);
				repro.save(video);
			}
		}
		response.setStatus(status);
		return null;
	}
	
	//@POST(VIDEO_SVC_PATH + "/{id}/unlike")
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH+"/{id}/unlike",method=RequestMethod.POST)
	public Void unlikeVideo(
			@PathVariable(value="id") long id,
			HttpServletResponse response,
			Principal principal )
	{
		int status = HttpServletResponse.SC_NOT_FOUND;
		Video video = repro.findOne(id);
		if (video != null && principal != null)
		{		
			if (video.getLikes() == (long) 0)
			{
				status = HttpServletResponse.SC_BAD_REQUEST;			
			}
			else
			{
				status = HttpServletResponse.SC_OK;
				video.setUserUnLike(principal.getName());
				repro.save(video);
			}
		}
		response.setStatus(status);
		return null;
	}
	
	//@GET(VIDEO_TITLE_SEARCH_PATH)
	@RequestMapping(value=VideoSvcApi.VIDEO_TITLE_SEARCH_PATH,method=RequestMethod.GET)
	public @ResponseBody Collection<Video> findByTitle(
			@RequestParam(value=VideoSvcApi.TITLE_PARAMETER) String title,
			HttpServletResponse response)
	{
		//GET /video/search/findByName?title={title}
		//   - Returns a list of videos whose titles match the given parameter or an empty
		//     list if none are found
		
		Collection <Video> vlist = repro.findByName(title);
		int status = HttpServletResponse.SC_NOT_FOUND;
		
		if (vlist != null && vlist.size() > 0)
		{
			status = HttpServletResponse.SC_OK;
		}
		response.setStatus(status);
		return vlist;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_DURATION_SEARCH_PATH,method=RequestMethod.GET)
	public @ResponseBody Collection<Video> findByDurationLessThan(
			@RequestParam(value=VideoSvcApi.DURATION_PARAMETER) long duration,
			HttpServletResponse response)
	{
		Collection <Video> vlist = (Collection <Video>) repro.findByDurationLessThan(duration);
		
		int status = HttpServletResponse.SC_NOT_FOUND;
		
		if (vlist != null && vlist.size() > 0)
		{
			status = HttpServletResponse.SC_OK;
		}
		response.setStatus(status);
		return vlist;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH+"/{id}/likedby",method=RequestMethod.GET)
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(
			@PathVariable(value="id") long id,
			HttpServletResponse response
			)
	{
		int status = HttpServletResponse.SC_NOT_FOUND;
		Video video = repro.findOne(id);
		Collection<String> vlist = video.getLikesBy();
		if (video != null)
		{
			status = HttpServletResponse.SC_OK;
		}
		response.setStatus(status);
		return vlist;
	}
}
