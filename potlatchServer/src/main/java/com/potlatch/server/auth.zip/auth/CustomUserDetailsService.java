package org.magnum.mobilecloud.video.auth;

import org.magnum.mobilecloud.video.repository.UserInfoRepository;
import org.magnum.mobilecloud.video.repository.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.core.support.RepositoryFactoryBeanSupport;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CustomUserDetailsService implements UserDetailsService{

	@Autowired(required = true)		
	private UserInfoRepository ui_repro;	
	
	public CustomUserDetailsService()
	{
		super();
		//this.user_repro = user_repro;
		
//		RepositoryFactorySupport factory = 
//		UserRepository repository = factory.getRepository(UserRepository.class);

	//	RepositoryFactoryBeanSupport factorybean = new RepositoryFactoryBeanSupport();
	//	RepositoryFactorySupport factory;
	//	ui_repro = factory.getRepository(UserInfoRepository.class);
		
		if (ui_repro != null && ui_repro.count() <= 0)
		{
			this.ui_repro.save(new UserInfo("admin", "pass"));
		}

	}
	
	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		User udetail = null;
		
		if (ui_repro != null)
		{		
			UserInfo user = (UserInfo) ui_repro.findByUsername(username);
			udetail = (User) User.create(
					user.getUsername(), 
					user.getPassword(), "ADMIN", "USER");		
		}
		return udetail;
	}

}
